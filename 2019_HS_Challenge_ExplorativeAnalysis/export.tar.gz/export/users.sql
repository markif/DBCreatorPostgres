--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE db_admin;
ALTER ROLE db_admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md5f66d74fea0edc866ab80bbfaecf3e1cf';
CREATE ROLE db_user;
ALTER ROLE db_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'md5e5d80135ab19725a774c129455d84880';






--
-- PostgreSQL database cluster dump complete
--

