--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE bank_user;
ALTER ROLE bank_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'md5032bf85b5da4ae6ad34c476606fbb3f4';
CREATE ROLE db_admin;
ALTER ROLE db_admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md5f66d74fea0edc866ab80bbfaecf3e1cf';






--
-- PostgreSQL database cluster dump complete
--

